import DestekMerkezi from "../../../components/DestekMerkezi";

export default function Page() {
  return <DestekMerkezi />;
}
