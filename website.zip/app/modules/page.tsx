import ModulesPage from './modules';

export default function Page() {
  return <ModulesPage />;
}
