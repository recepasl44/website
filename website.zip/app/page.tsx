import WebsiteDesign from "./website-design";

export default function Page() {
  return <WebsiteDesign />;
}
