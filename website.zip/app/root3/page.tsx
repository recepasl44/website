import Root3 from "./root3";
import Root2 from "../../components/root2"

export default function Page() {
  return (
    <>
      <Root3 />
      <Root2/>
    </>
  );
}
