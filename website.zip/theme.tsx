"use client";
import { createTheme } from "@mui/material/styles";

const muiTheme = createTheme({});

export default muiTheme;
